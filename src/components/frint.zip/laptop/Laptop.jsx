import './laptop.scss'

const Laptop = () => {
  return (
    <div className='laptop'>
      <div class="frint-top-video">
        <div class="frint-top-video2">
          <iframe
            width="500"
            height="280"
            src="https://www.youtube.com/embed/4r3XdWj269_g?rel=0&amp;showinfo=0"
            frameborder="0"
            allowfullscreen
          ></iframe>
        </div>
      </div>
    </div>
  );
};

export default Laptop;
