import styles from './gallery.scss'

const Gallery = () => {
    const alignCenter = { display: 'flex', alignItems: 'center' }
    return (
      <div>
        ty
      </div>
    )
}

export default Gallery
